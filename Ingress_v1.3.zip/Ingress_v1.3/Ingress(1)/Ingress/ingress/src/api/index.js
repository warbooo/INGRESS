// src/api/index.js
import axios from 'axios';

const api = axios.create({
  baseURL: 'https://your-backend-api-url.com'  // 替换为你的后端 API URL
});

export const checkInRequest = (userId, targetId) =>
  api.post('/check-in', { userId, targetId });

export default api;
