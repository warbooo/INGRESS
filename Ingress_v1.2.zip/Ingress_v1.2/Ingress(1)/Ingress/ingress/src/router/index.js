import { createRouter, createWebHistory } from 'vue-router';
import LoginPage from '../components/LoginPage.vue';
import AdminDashboard from '../components/AdminDashboard.vue';
import UserDashboard from '../components/UserDashboard.vue';
import GuestDashboard from '../components/GuestDashboard.vue';
import CheckpointStore from '../components/CheckpointCard.vue'; 

const routes = [
  {
    path: '/',
    name: 'Login',
    component: LoginPage,
  },
  {
    path: '/admin-dashboard',
    name: 'AdminDashboard',
    component: AdminDashboard,
    meta: { requiresAuth: true, userType: 'admin' },
  },
  {
    path: '/user-dashboard',
    name: 'UserDashboard',
    component: UserDashboard,
    meta: { requiresAuth: true, userType: 'user' },
  },
  {
    path: '/guest-dashboard',
    name: 'GuestDashboard',
    component: GuestDashboard,
    meta: { requiresAuth: true, userType: 'guest' },
  },
  {
    path: '/checkpoint-store',
    name: 'CheckpointStore',
    component: CheckpointStore, // 添加 CheckpointStore 路由
    meta: { requiresAuth: true }, // 需要身份验证
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

// 导航守卫
router.beforeEach((to, from, next) => {
  const userType = localStorage.getItem('userType');

  if (to.meta.requiresAuth) {
    if (!userType) {
      next('/');
    } else if (to.meta.userType && to.meta.userType !== userType) {
      next(`/${userType}-dashboard`);
    } else {
      next();
    }
  } else {
    next();
  }
});

export default router;
